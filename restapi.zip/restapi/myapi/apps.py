from django.apps import AppConfig


class RestapiConfig(AppConfig):
    name = 'myapi'
