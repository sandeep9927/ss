from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
from .serializers import *
from rest_framework import viewsets
from .models import *
from .serializers import *

class StudentRecordViewSet(ModelViewSet):
    
    queryset = StudentData.objects.all()
    serializer_class = StudentSerializer



