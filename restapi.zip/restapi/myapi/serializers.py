from rest_framework import serializers, status
from .models import *
from rest_framework.serializers import SerializerMethodField


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'first_name','last_name', 'email','password',)
    

class StudentSerializer(serializers.ModelSerializer):

    username = SerializerMethodField()
    email = SerializerMethodField()
    user = UserSerializer(required=False)

    class Meta:
        model = StudentData
        fields = ('id', 'user','college','subject','city','username','email')

    def get_username(self, obj):
        return str(obj.user.username)
    def get_email(self, obj):
        return str(obj.user.email)

    def create(self, validated_data):
        
        user_data = validated_data.pop('user')
        user = UserSerializer.create(UserSerializer(), validated_data=user_data)
        student, created = StudentData.objects.update_or_create(user=user,
        subject=validated_data.pop('subject'),college=validated_data.pop('college'),city=validated_data.pop('city'))
        return student



    def update(self, instance, validated_data):
        
        user_data = validated_data.pop('user')
        instance.subject = validated_data.get('subject', instance.subject)
        instance.college = validated_data.get('college', instance.college)
        instance.city = validated_data.get('city', instance.city)
        instance.save()

        for u_data in user_data:
            ur = user.pop(0)
            ur.username =  u_data.get('username', ur.username)
            ur.first_name =  u_data.get('first_name', ur.first_name)
            ur.last_name =  u_data.get('last_name', ur.last_name)
            ur.email =  u_data.get('email', ur.email)
            ur.password =  u_data.get('password', ur.password)
            
            
            ur.save()
        return instance

        

    