from django.contrib import admin
from django.urls import path, include



from rest_framework.routers import DefaultRouter

from myapi.views import StudentRecordViewSet
from myapi import views
router = DefaultRouter()
router.register("Student", StudentRecordViewSet)


urlpatterns = [
    path('',include(router.urls)),
    path('admin/', admin.site.urls),
    path('api-auth/', include('rest_framework.urls',namespace='rest_framework')),
    path('api/',views.StudentRecordViewSet.as_view,
    name='students_list'),  


]

